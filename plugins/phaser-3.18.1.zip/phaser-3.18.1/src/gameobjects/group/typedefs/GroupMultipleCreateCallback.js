/**
 * @callback Phaser.Types.GameObjects.Group.GroupMultipleCreateCallback
 * @since 3.0.0
 *
 * @param {Phaser.GameObjects.GameObject[]} items - The newly created group members
 */
